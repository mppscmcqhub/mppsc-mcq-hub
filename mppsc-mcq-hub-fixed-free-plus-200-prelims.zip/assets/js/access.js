
const KEY="mppsc_prelims_paid_access";
function paid(){return localStorage.getItem(KEY)==="paid"}
function demoUnlock(){localStorage.setItem(KEY,"paid")}
function requirePaid(){
  if(!paid()){
    const ok=confirm("यह Paid PRELIMS Course है। Demo access unlock करें?");
    if(ok) demoUnlock(); else location.href="../../prelims.html";
  }
}
function saveScore(code,score,total){
  const x=JSON.parse(localStorage.getItem("mppsc_scores")||"{}");
  x[code]={score,total,date:new Date().toISOString()};
  localStorage.setItem("mppsc_scores",JSON.stringify(x));
}
